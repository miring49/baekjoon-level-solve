#include <bits/stdc++.h>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;

// 토마토 7576?

struct tomato {
    int y, x;
};

queue<tomato> q;

// 우하좌상으로 탐색하게 해주는 배열
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};
int n, m, out = 0;
int graph[1001][1001];

bool IsInside(int ny, int nx) { // 경계 넘어가지 않게 하는 함수
    return (0 <= nx and 0 <= ny and nx < m and ny < n);
}

void bfs() {
    while (!q.empty()) {
        int y = q.front().y;
        int x = q.front().x;
        q.pop();
        for (int i = 0; i < 4; i++) {
            int ny = y + dy[i];
            int nx = x + dx[i];
            if (IsInside(ny,nx) == 1 and graph[ny][nx] == 0) {
                graph[ny][nx] = graph[y][x] + 1; // 그래프 배열에 시간 기록
                q.push({ ny, nx });
            }
        }
    }
}

int main() {
    fastio;
    cin >> m >> n;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> graph[i][j];
            if (graph[i][j] == 1) { // 익은토마토(1) -> 큐
                q.push({i, j});
            }
        }
    }
    bfs();
    // 출력
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            // 익지않은 토마토(0)가 존재할 경우
            if (graph[i][j] == 0) {
                cout << -1 << "\n";
                return 0;
            }
            if (out < graph[i][j]) { // 가장 큰 값 찾기
                out = graph[i][j];
            }
        }
    }
    cout << out - 1;
    return 0;
}