#include <iostream>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;

// inorder, postorder 주면 preorder 출력

vector<int> Index;
vector<int> inorder;
vector<int> postorder;

void getpreorder(int instart, int inend, int poststart, int postend) // 받은 배열의 시작과 끝을 루트노드로 잘 나눠서 재귀
{
    if (instart > inend or poststart > postend) {
        return;
    }
    int rootindex = Index[postorder[postend]];
    int leftsize = rootindex - instart;
    cout << inorder[rootindex] << " ";
    getpreorder(instart, rootindex - 1, poststart, poststart + leftsize - 1);
    getpreorder(rootindex + 1, inend, poststart + leftsize, postend - 1);
}

int main() {
    fastio;
    int n; cin >> n;
    inorder.resize(n + 1);
    Index.resize(n + 1);
    postorder.resize(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> inorder[i];
        Index[inorder[i]] = i;
    }
    for (int i = 1; i <= n; i++) {
        cin >> postorder[i];
    }
    getpreorder(1, n, 1, n);
    return 0;
}