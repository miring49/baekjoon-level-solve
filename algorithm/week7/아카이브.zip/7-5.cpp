#include <bits/stdc++.h>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;

// 영웅희재

vector< vector<int> > List;
vector<int> dist;
int out = 1;

void bfs(int x)
{
    queue<int> q;
    q.push(x);
    dist[x] = 0;

    while (!q.empty())
    {
        int y = q.front();
        q.pop();
        if (dist[x] == 2) continue;
        for (int j : List[y])
        {
            if (dist[j] == -1)
            {
                dist[j] = dist[x] + 1;
                out++;
                q.push(j);
            }
        }
    }
}


int main() {
    fastio;
    int n, m; cin >> n >> m;
    dist.assign(n + 1, -1);
    List.resize(n + 1);
    for (int i = 0; i < m; i++) {
        int a, b; cin >> a >> b;
        List[a].push_back(b);
        List[b].push_back(a);
    }
    bfs(1);
    cout << out;
    return 0;
}