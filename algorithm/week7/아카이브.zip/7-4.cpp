#include <bits/stdc++.h>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;

// 컴퓨터 윔 바이러스 확산 개수 세기

vector<vector<int>> List;
vector<bool> visit;
int out = 0;

void dfs(int x) { // 깊이 탐색으로 확인
    out++;
    visit[x] = true;
    for(int j : List[x])
    {
        if (!visit[j])
            dfs(j);
    }
}

int main() {
    fastio;
    int n, m; cin >> n >> m; // n은 컴퓨터의 수, m은 연결되어있는 수
    visit.resize(n + 1);
    List.resize(n + 1);
    // 이중 벡터에 연결리스트 만들기
    for (int i = 0; i < m; i++) {
        int a, b; cin >> a >> b;
        List[a].push_back(b);
        List[b].push_back(a);
    }
    dfs(1); // 1번 컴퓨터부터 시작함
    cout << out - 1;
    return 0;
}