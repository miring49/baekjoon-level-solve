#include <iostream>
#include <vector>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;
void insertion_sort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        // 오름차순: arr[j] > key
        while (j >= 0 && arr[j] < key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}
int main() {
    fastio;
    vector<int> arr = {5, 2, 9, 1, 5, 6};
    insertion_sort(arr);
    for (int x : arr) {
        cout << x << " ";
    }
    return 0;
}
