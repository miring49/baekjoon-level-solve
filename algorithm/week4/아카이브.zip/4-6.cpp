#include <iostream>
#include <vector>
#include <algorithm>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;


int main() {
    fastio;
    int n, m; cin >> n >> m;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    vector<int> b(m);
    for (int i = 0; i < m; i++) {
        cin >> b[i];
    }
    sort(b.begin(), b.end());
    vector<int> diff_b(m);
    for (int i = 0; i < m; i++) {
        diff_b[i] = b[i] - b[0];
    }
    int beautiful_count = 0;

    for (int i = 0; i <= n - m; i++) {
        vector<int> sub_a(a.begin() + i, a.begin() + i + m);
        sort(sub_a.begin(), sub_a.end());
        bool is_beautiful = true;
        for (int j = 0; j < m; j++) {
            if (sub_a[j] - sub_a[0] != diff_b[j]) {
                is_beautiful = false;
                break;
            }
        }
        if (is_beautiful) {
            beautiful_count++;
        }
    }
    cout << beautiful_count << "\n";
    return 0;
}
