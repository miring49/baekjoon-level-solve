#include <iostream>
#include <vector>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;

void bubble_sort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        bool swapped = false;
        for (int j = 0; j < n - 1 - i; j++) {
            // 오름차순: arr[j] > arr[j + 1]
            if (arr[j] < arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
}

int main() {
    fastio;
    vector<int> arr = {5, 2, 9, 1, 5, 6};
    bubble_sort(arr);
    for (int x : arr) {
        cout << x << " ";
    }
    cout << "\n";
    return 0;
}
