#include <iostream>
#include <string>
#include <map>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;

int main() {
    fastio;
    int n; cin >> n;
    map <string, int> m;
    for (int i = 0; i < n; i++) {
        string s; cin >> s;
        m[s]++;
    }
    string winner = "";
    int maxVotes = -1;
    for (const auto& entry : m) {
        if (entry.second > maxVotes) {
            maxVotes = entry.second;
            winner = entry.first;
        }
    }
    cout << winner << "\n";
    return 0;
}