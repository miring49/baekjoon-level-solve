#include <iostream>
#include <vector>
#include <string>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;
bool compare(const string& a, const string& b) {
    if (a.length() != b.length()) {
        return a.length() < b.length();
    }
    return a < b;
}
int main() {
    fastio;
    int n; cin >> n;
    vector<string> words(n);
    for (int i = 0; i < n; i++) {
        cin >> words[i];
    }
    sort(words.begin(), words.end(), compare);
    words.erase(unique(words.begin(), words.end()), words.end());

    for (const string& word : words) {
        cout << word << "\n";
    }
    return 0;
}

