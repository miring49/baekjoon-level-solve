#include <iostream>
#include <set>
#define fastio cin.tie(0)->sync_with_stdio(0)
using namespace std;


int main() {
    fastio;
    int n; cin >> n;
    set<int> s;
    for (int i = 0; i < n; i++) {
        int x; cin >> x;
        s.insert(x);
    }
    for (int y : s) {
        cout << y << " ";
    }
    cout << "\n";
    return 0;
}

